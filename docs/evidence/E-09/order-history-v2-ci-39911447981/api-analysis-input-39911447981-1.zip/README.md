# API test analysis input

This packet contains 10 completed test invocations (planned: 10) of
`Submitted order appears in account history`, test ID `ORDER-HISTORY-01`, on `revision-01`.
Each run is a fresh Jest process. Failed tests may be retried at most 0
times inside that process; the first attempt is not a retry. Every attempt uses
a new application instance and isolated SQLite in-memory fixture with zero orders.
The APIs are the real EShop endpoints, exercised over local HTTP by Supertest.

## Files and clocks

- `history.json`: initial/final verdicts, invocation count and retry relationship.
- `run-NN/events.jsonl`: original structured observations, one event per line.
- `run-NN/console.log`: a line-numbered rendering of those same events, not new runs.
- `run-NN/attempts.json`: original per-attempt verdicts, assertions and observations.
- `run-NN/result.json`: final result checked against the native Jest report.

`elapsed_ms` is milliseconds from a monotonic clock in that run's Jest process.
It includes fixture setup and retries. Compare event times only within the same
run. `time_utc` is wall time for orientation, not the clock used to infer ordering.
`sequence` breaks ties. `process_duration_ms` in history measures the whole Jest
process including startup; it is not test duration. Native Jest test duration is
listed separately. Request IDs connect client send/receive and server receipt/
completion. `history` and `confirmation` identify two separate history requests;
both observations are retained. Assertions determine the test result.

## Scope

Environment: Node v24.14.0, Jest 30.5.2, Linux.
Run/revision labels are aliases. Original CI IDs, source mapping and experiment
controls are retained by the organizer outside this packet. Source code, runner
stack/code frames, authentication data and design explanations are not supplied.
Event values and attempt results have not been rewritten to suggest a cause.
Use only this packet. An observed pattern is evidence for a hypothesis, not by
itself confirmation of a particular implementation defect.
