# Analysis request

Read the supplied log/report/history only; do not open the repository or other sources.
1. Summarize initial attempts, retries and final results without double-counting files.
2. Give at most three hypotheses ranked by evidence. Cite run/file/line or JSON field,
   distinguish observations from hypotheses, and state missing information/uncertainty.
3. Propose exactly three next checks, explaining which outcomes support or weaken each hypothesis.
Do not claim to have executed those checks or fixed code. Record actual analysis time
if measurable; do not estimate or invent it. Save the answer before seeing another analyst's output.
